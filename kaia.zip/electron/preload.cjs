const { contextBridge, ipcRenderer } = require('electron');

/**
 * Preload script para KAIA Desktop.
 * Expone un puente IPC seguro y aislado entre el Renderer y el proceso principal.
 */
contextBridge.exposeInMainWorld('kaiaDesktop', {
  isDesktop: true,

  // Información de entorno y rutas portables
  getEnvironment: () => ipcRenderer.invoke('kaia:get-environment'),

  // Base de datos local
  readDatabase: () => ipcRenderer.invoke('kaia:db-read'),
  writeDatabase: (data) => ipcRenderer.invoke('kaia:db-write', data),
  executeSql: (sql, params) => ipcRenderer.invoke('kaia:db-execute-sql', { sql, params }),

  // Copias de seguridad
  createBackup: (note) => ipcRenderer.invoke('kaia:db-backup', note),

  // Apertura de carpetas en el explorador de Windows (pendrive)
  openFolder: (type) => ipcRenderer.invoke('kaia:open-folder', type),

  // Exportaciones de documentos, facturas y presupuestos
  saveExportFile: (fileName, data, mimeType) =>
    ipcRenderer.invoke('kaia:save-export-file', { fileName, data, mimeType }),
  saveDocumentFile: (fileName, data) =>
    ipcRenderer.invoke('kaia:save-document-file', { fileName, data }),

  // Controles de ventana
  windowControl: (action) => ipcRenderer.invoke('kaia:window-control', action),
});
