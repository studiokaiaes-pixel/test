const path = require('path');
const fs = require('fs');

/**
 * Resuelve el directorio base del entorno portable de KAIA.
 * 
 * En Windows portable (generado por electron-builder portable target):
 * - process.env.PORTABLE_EXECUTABLE_DIR apunta al directorio exacto donde el usuario
 *   ha colocado el ejecutable KAIA.exe (por ejemplo, E:\\ o D:\\KAIA\\ en un pendrive).
 * 
 * En desarrollo:
 * - Se utiliza <proyecto>/data para aislar los datos sin tocar el código fuente.
 */
function getPortableBaseDir(app) {
  // 1. Ejecutable portable de Windows (pendrive o carpeta independiente)
  if (process.env.PORTABLE_EXECUTABLE_DIR) {
    return process.env.PORTABLE_EXECUTABLE_DIR;
  }

  // 2. Ejecutable empaquetado directo
  if (app && app.isPackaged) {
    return path.dirname(process.execPath);
  }

  // 3. Entorno de desarrollo local
  return path.resolve(__dirname, '..', 'data');
}

/**
 * Resuelve y garantiza la existencia de las 4 carpetas empresariales requeridas:
 * - database/: base de datos local SQLite y archivos de control
 * - documents/: contratos, especificaciones y adjuntos de clientes
 * - backups/: copias de seguridad fechadas y automáticas
 * - exports/: presupuestos, facturas e informes generados
 */
function resolveAppPaths(app) {
  const baseDir = getPortableBaseDir(app);
  const isPortable = Boolean(process.env.PORTABLE_EXECUTABLE_DIR);
  const isDev = app ? !app.isPackaged : process.env.NODE_ENV === 'development';

  const paths = {
    baseDir,
    databaseDir: path.join(baseDir, 'database'),
    documentsDir: path.join(baseDir, 'documents'),
    backupsDir: path.join(baseDir, 'backups'),
    exportsDir: path.join(baseDir, 'exports'),
    dbSqlitePath: path.join(baseDir, 'database', 'kaia.sqlite'),
    dbJsonPath: path.join(baseDir, 'database', 'kaia-database.json'),
    schemaSqlPath: path.join(baseDir, 'database', 'kaia_schema.sql'),
    isPortable,
    isDev,
  };

  // Crear automáticamente las carpetas si no existen
  const requiredDirs = [
    paths.databaseDir,
    paths.documentsDir,
    paths.backupsDir,
    paths.exportsDir,
  ];

  requiredDirs.forEach((dir) => {
    try {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
      }
    } catch (err) {
      console.error(`[KAIA Portable] Error creando directorio ${dir}:`, err);
    }
  });

  return paths;
}

/**
 * Configura Electron para que NO use AppData en Windows, manteniendo todos
 * los datos de sesión y caché localizados en el propio pendrive.
 */
function configurePortableUserData(app) {
  const baseDir = getPortableBaseDir(app);
  // Redirigir userData a una subcarpeta portable para no dejar rastro en %APPDATA%
  const portableUserData = path.join(baseDir, 'data', 'userdata');
  try {
    if (!fs.existsSync(portableUserData)) {
      fs.mkdirSync(portableUserData, { recursive: true });
    }
    app.setPath('userData', portableUserData);
    console.log(`[KAIA Portable] UserData configurado en: ${portableUserData}`);
  } catch (err) {
    console.warn('[KAIA Portable] No se pudo redirigir userData, usando por defecto:', err);
  }
}

module.exports = {
  getPortableBaseDir,
  resolveAppPaths,
  configurePortableUserData,
};
