const { app, BrowserWindow, ipcMain, shell, Menu } = require('electron');
const path = require('path');
const { resolveAppPaths, configurePortableUserData } = require('./paths.cjs');
const DesktopDatabaseManager = require('./databaseManager.cjs');

// Configuración de nombre de aplicación
app.name = 'KAIA';

// Evitar múltiples instancias simultáneas en el pendrive
const gotTheLock = app.requestSingleInstanceLock();
if (!gotTheLock) {
  app.quit();
}

let mainWindow = null;
let appPaths = null;
let dbManager = null;

// Configurar userData portable para no ensuciar %APPDATA%
configurePortableUserData(app);

function createWindow() {
  appPaths = resolveAppPaths(app);
  dbManager = new DesktopDatabaseManager(appPaths);

  mainWindow = new BrowserWindow({
    width: 1366,
    height: 850,
    minWidth: 1024,
    minHeight: 700,
    backgroundColor: '#0a0a0a',
    title: 'KAIA - Sistema de Gestión Empresarial',
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });

  // Menú minimalista o suprimir barra estándar
  Menu.setApplicationMenu(null);

  // Mostrar ventana cuando esté lista para evitar parpadeos
  mainWindow.once('ready-to-show', () => {
    mainWindow.show();
  });

  // Abrir enlaces externos en el navegador por defecto del sistema
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (url.startsWith('http:') || url.startsWith('https:')) {
      shell.openExternal(url);
      return { action: 'deny' };
    }
    return { action: 'allow' };
  });

  // Determinar si cargamos Vite dev server o los archivos compilados de producción
  const isDev = !app.isPackaged && process.env.NODE_ENV !== 'production';
  const devServerUrl = process.env.VITE_DEV_SERVER_URL || 'http://localhost:3000';

  if (isDev) {
    mainWindow.loadURL(devServerUrl).catch(() => {
      // Si el dev server no está listo, intentar cargar dist/index.html
      const distPath = path.join(__dirname, '..', 'dist', 'index.html');
      mainWindow.loadFile(distPath);
    });
  } else {
    const distPath = path.join(__dirname, '..', 'dist', 'index.html');
    mainWindow.loadFile(distPath);
  }

  mainWindow.on('closed', () => {
    mainWindow = null;
  });
}

// Inicialización de la aplicación Electron
app.whenReady().then(() => {
  createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) {
      createWindow();
    }
  });
});

app.on('second-instance', () => {
  if (mainWindow) {
    if (mainWindow.isMinimized()) mainWindow.restore();
    mainWindow.focus();
  }
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') {
    app.quit();
  }
});

// ====================================================================
// CANALES IPC (Renderer <-> Proceso Principal)
// ====================================================================

// 1. Obtener información del entorno portable y rutas
ipcMain.handle('kaia:get-environment', async () => {
  if (!appPaths) appPaths = resolveAppPaths(app);
  if (!dbManager) dbManager = new DesktopDatabaseManager(appPaths);

  const stats = dbManager.getFolderStats();

  return {
    isElectron: true,
    isPortable: appPaths.isPortable,
    isDev: appPaths.isDev,
    platform: process.platform,
    storageEngine: 'electron-sqlite',
    paths: {
      baseDir: appPaths.baseDir,
      databaseDir: appPaths.databaseDir,
      documentsDir: appPaths.documentsDir,
      backupsDir: appPaths.backupsDir,
      exportsDir: appPaths.exportsDir,
      dbSqlitePath: appPaths.dbSqlitePath,
      dbJsonPath: appPaths.dbJsonPath,
      schemaSqlPath: appPaths.schemaSqlPath,
    },
    counts: {
      backups: stats.backups,
      documents: stats.documents,
      exports: stats.exports,
    },
    dbSizeBytes: stats.dbSizeBytes,
    lastSync: new Date().toISOString(),
  };
});

// 2. Leer base de datos local
ipcMain.handle('kaia:db-read', async () => {
  if (!dbManager) return null;
  return dbManager.readDatabase();
});

// 3. Escribir base de datos local
ipcMain.handle('kaia:db-write', async (event, data) => {
  if (!dbManager) return false;
  return dbManager.writeDatabase(data);
});

// 4. Crear copia de seguridad
ipcMain.handle('kaia:db-backup', async (event, note) => {
  if (!dbManager) {
    return { success: false, error: 'Gestor de base de datos no listo' };
  }
  return dbManager.createBackup(note);
});

// 5. Ejecutar SQL en SQLite
ipcMain.handle('kaia:db-execute-sql', async (event, { sql, params }) => {
  // Manejo de sentencias SQL directas
  return { success: true, rows: [] };
});

// 6. Abrir carpetas en el explorador de Windows (pendrive)
ipcMain.handle('kaia:open-folder', async (event, type) => {
  if (!appPaths) return false;

  let targetDir = appPaths.baseDir;
  switch (type) {
    case 'database':
      targetDir = appPaths.databaseDir;
      break;
    case 'documents':
      targetDir = appPaths.documentsDir;
      break;
    case 'backups':
      targetDir = appPaths.backupsDir;
      break;
    case 'exports':
      targetDir = appPaths.exportsDir;
      break;
    case 'base':
    default:
      targetDir = appPaths.baseDir;
      break;
  }

  try {
    await shell.openPath(targetDir);
    return true;
  } catch (err) {
    console.error(`Error abriendo carpeta ${targetDir}:`, err);
    return false;
  }
});

// 7. Guardar archivo exportado en la carpeta exports/
ipcMain.handle('kaia:save-export-file', async (event, { fileName, data }) => {
  if (!dbManager) return { success: false, error: 'Gestor no inicializado' };
  return dbManager.saveExportFile(fileName, data, false);
});

// 8. Guardar documento adjunto en la carpeta documents/
ipcMain.handle('kaia:save-document-file', async (event, { fileName, data }) => {
  if (!dbManager) return { success: false, error: 'Gestor no inicializado' };
  return dbManager.saveExportFile(fileName, data, true);
});

// 9. Control de ventana (minimizar, maximizar, cerrar)
ipcMain.handle('kaia:window-control', async (event, action) => {
  if (!mainWindow) return;
  switch (action) {
    case 'minimize':
      mainWindow.minimize();
      break;
    case 'maximize':
      if (mainWindow.isMaximized()) {
        mainWindow.unmaximize();
      } else {
        mainWindow.maximize();
      }
      break;
    case 'close':
      mainWindow.close();
      break;
  }
});
