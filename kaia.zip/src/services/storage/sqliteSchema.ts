import { KaiaDatabase } from '../../types';

/**
 * Esquema DDL oficial de SQLite para KAIA Business Management System.
 * Diseñado para persistencia relacional local sin dependencias de internet.
 */
export const KAIA_SQLITE_DDL = `
-- ====================================================================
-- KAIA BUSINESS MANAGEMENT SYSTEM - ESQUEMA RELACIONAL SQLITE
-- Archivo: database/kaia.sqlite
-- Compatible con SQLite 3.x y SQLite portable
-- ====================================================================

PRAGMA foreign_keys = ON;
PRAGMA encoding = 'UTF-8';
PRAGMA journal_mode = WAL;

-- 1. EMPRESA Y CONFIGURACIÓN FISCAL
CREATE TABLE IF NOT EXISTS company (
  id TEXT PRIMARY KEY DEFAULT 'COMPANY_DEFAULT',
  nombreComercial TEXT NOT NULL,
  razonSocial TEXT NOT NULL,
  cif TEXT NOT NULL,
  direccion TEXT,
  codigoPostal TEXT,
  ciudad TEXT,
  provincia TEXT,
  pais TEXT DEFAULT 'España',
  telefono TEXT,
  email TEXT,
  web TEXT,
  iban TEXT,
  banco TEXT,
  swift TEXT,
  condicionesPago TEXT,
  ivaPorDefecto REAL DEFAULT 21,
  retencionIRPF REAL DEFAULT 0,
  cuentaBancaria TEXT,
  registroMercantil TEXT,
  condicionesDefecto TEXT,
  pieFacturaDefecto TEXT,
  moneda TEXT DEFAULT 'EUR',
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 2. CONFIGURACIÓN DEL SISTEMA
CREATE TABLE IF NOT EXISTS settings (
  id TEXT PRIMARY KEY DEFAULT 'SETTINGS_DEFAULT',
  tema TEXT DEFAULT 'claro',
  formatoFecha TEXT DEFAULT 'DD/MM/YYYY',
  moneda TEXT DEFAULT 'EUR',
  autoGuardar INTEGER DEFAULT 1,
  backupUltimaFecha TEXT,
  prefijoPresupuesto TEXT DEFAULT 'PRE',
  prefijoFactura TEXT DEFAULT 'FAC',
  prefijoProyecto TEXT DEFAULT 'PRO',
  prefijoCliente TEXT DEFAULT 'CLI',
  incluirAno INTEGER DEFAULT 1,
  digitosNumero INTEGER DEFAULT 4,
  separadorDecimal TEXT DEFAULT ',',
  config_json TEXT,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 3. CLIENTES
CREATE TABLE IF NOT EXISTS clients (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  apellidos TEXT,
  empresa TEXT,
  cif TEXT,
  email TEXT,
  telefono TEXT,
  direccion TEXT,
  codigoPostal TEXT,
  ciudad TEXT,
  provincia TEXT,
  pais TEXT DEFAULT 'España',
  notas TEXT,
  estado TEXT DEFAULT 'Activo',
  fechaAlta TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_clients_empresa ON clients(empresa);
CREATE INDEX IF NOT EXISTS idx_clients_cif ON clients(cif);
CREATE INDEX IF NOT EXISTS idx_clients_estado ON clients(estado);

-- 4. PROYECTOS
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  titulo TEXT NOT NULL,
  clienteId TEXT NOT NULL,
  servicio TEXT,
  descripcion TEXT,
  estado TEXT DEFAULT 'En curso',
  fechaInicio TEXT,
  fechaPrevista TEXT,
  importe REAL DEFAULT 0,
  responsable TEXT,
  presupuestoId TEXT,
  notas TEXT,
  tareas_json TEXT,
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (clienteId) REFERENCES clients(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_projects_cliente ON projects(clienteId);
CREATE INDEX IF NOT EXISTS idx_projects_estado ON projects(estado);

-- 5. PRESUPUESTOS
CREATE TABLE IF NOT EXISTS quotes (
  id TEXT PRIMARY KEY,
  clienteId TEXT NOT NULL,
  fecha TEXT NOT NULL,
  validez TEXT,
  estado TEXT DEFAULT 'Borrador',
  subtotal REAL DEFAULT 0,
  descuentoTotal REAL DEFAULT 0,
  ivaTotal REAL DEFAULT 0,
  irpfTotal REAL DEFAULT 0,
  total REAL DEFAULT 0,
  condicionesPago TEXT,
  formaPago TEXT,
  plazoEntrega TEXT,
  revisiones TEXT,
  cancelacion TEXT,
  notas TEXT,
  observaciones TEXT,
  plantillaConfig_json TEXT,
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (clienteId) REFERENCES clients(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_quotes_cliente ON quotes(clienteId);
CREATE INDEX IF NOT EXISTS idx_quotes_estado ON quotes(estado);
CREATE INDEX IF NOT EXISTS idx_quotes_fecha ON quotes(fecha);

-- LÍNEAS DE PRESUPUESTO
CREATE TABLE IF NOT EXISTS quote_lines (
  id TEXT PRIMARY KEY,
  quoteId TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  cantidad REAL NOT NULL DEFAULT 1,
  precioUnitario REAL NOT NULL DEFAULT 0,
  iva REAL DEFAULT 21,
  descuento REAL DEFAULT 0,
  totalLinea REAL DEFAULT 0,
  orden INTEGER DEFAULT 0,
  FOREIGN KEY (quoteId) REFERENCES quotes(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_quote_lines_quoteId ON quote_lines(quoteId);

-- 6. FACTURAS
CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  clienteId TEXT NOT NULL,
  presupuestoId TEXT,
  proyectoId TEXT,
  fechaEmision TEXT NOT NULL,
  fechaVencimiento TEXT NOT NULL,
  formaPago TEXT,
  metodoPago TEXT,
  cuentaBancaria TEXT,
  baseImponible REAL DEFAULT 0,
  ivaTotal REAL DEFAULT 0,
  irpfTotal REAL DEFAULT 0,
  total REAL DEFAULT 0,
  importePagado REAL DEFAULT 0,
  importePendiente REAL DEFAULT 0,
  estado TEXT DEFAULT 'Borrador',
  notas TEXT,
  pieFactura TEXT,
  plantillaConfig_json TEXT,
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (clienteId) REFERENCES clients(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_invoices_cliente ON invoices(clienteId);
CREATE INDEX IF NOT EXISTS idx_invoices_estado ON invoices(estado);
CREATE INDEX IF NOT EXISTS idx_invoices_fechaEmision ON invoices(fechaEmision);

-- LÍNEAS DE FACTURA
CREATE TABLE IF NOT EXISTS invoice_lines (
  id TEXT PRIMARY KEY,
  invoiceId TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  cantidad REAL NOT NULL DEFAULT 1,
  precioUnitario REAL NOT NULL DEFAULT 0,
  iva REAL DEFAULT 21,
  descuento REAL DEFAULT 0,
  totalLinea REAL DEFAULT 0,
  orden INTEGER DEFAULT 0,
  FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_invoice_lines_invoiceId ON invoice_lines(invoiceId);

-- PAGOS ASOCIADOS A FACTURAS
CREATE TABLE IF NOT EXISTS invoice_payments (
  id TEXT PRIMARY KEY,
  invoiceId TEXT NOT NULL,
  fecha TEXT NOT NULL,
  importe REAL NOT NULL,
  metodo TEXT,
  referencia TEXT,
  notas TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_invoice_payments_invoiceId ON invoice_payments(invoiceId);

-- 7. FINANZAS / MOVIMIENTOS DE TESORERÍA
CREATE TABLE IF NOT EXISTS finances (
  id TEXT PRIMARY KEY,
  fecha TEXT NOT NULL,
  tipo TEXT NOT NULL, -- 'Ingreso' o 'Gasto'
  categoria TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  importe REAL NOT NULL,
  metodo TEXT,
  estado TEXT DEFAULT 'Completado',
  clienteId TEXT,
  proyectoId TEXT,
  facturaId TEXT,
  fechaCreacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_finances_fecha ON finances(fecha);
CREATE INDEX IF NOT EXISTS idx_finances_tipo ON finances(tipo);
CREATE INDEX IF NOT EXISTS idx_finances_categoria ON finances(categoria);

-- 8. DOCUMENTOS Y ARCHIVOS LOCALES
CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  categoria TEXT,
  tamano TEXT,
  tipo TEXT,
  fechaSubida TEXT,
  clienteId TEXT,
  proyectoId TEXT,
  rutaLocal TEXT, -- Ruta relativa en documents/
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_documents_categoria ON documents(categoria);

-- 9. OPORTUNIDADES COMERCIALES (LEADS)
CREATE TABLE IF NOT EXISTS commercial_leads (
  id TEXT PRIMARY KEY,
  empresa TEXT NOT NULL,
  contacto TEXT,
  email TEXT,
  telefono TEXT,
  origen TEXT,
  servicioInteres TEXT,
  estado TEXT DEFAULT 'Contacto Inicial',
  valorEstimado REAL DEFAULT 0,
  fechaContacto TEXT,
  proximoSeguimiento TEXT,
  notas TEXT,
  fechaCreacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_leads_estado ON commercial_leads(estado);

-- 10. PROVEEDORES
CREATE TABLE IF NOT EXISTS suppliers (
  id TEXT PRIMARY KEY,
  proveedor TEXT NOT NULL,
  cif TEXT,
  contacto TEXT,
  email TEXT,
  telefono TEXT,
  web TEXT,
  servicio TEXT,
  condiciones TEXT,
  estado TEXT DEFAULT 'Activo',
  notas TEXT,
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 11. PRODUCTOS Y SERVICIOS
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  referencia TEXT,
  categoria TEXT,
  descripcion TEXT,
  precio REAL DEFAULT 0,
  iva REAL DEFAULT 21,
  stock INTEGER DEFAULT 0,
  stockMinimo INTEGER DEFAULT 0,
  proveedorId TEXT,
  estado TEXT DEFAULT 'Disponible',
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_products_referencia ON products(referencia);

-- 12. REGISTRO DE ACTIVIDAD / AUDITORÍA
CREATE TABLE IF NOT EXISTS activities (
  id TEXT PRIMARY KEY,
  fecha TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  tipo TEXT NOT NULL,
  entidadId TEXT,
  targetView TEXT,
  targetId TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_activities_fecha ON activities(fecha);
`;

/**
 * Función auxiliar para escapar cadenas en SQL de SQLite
 */
function sqlEscape(val: any): string {
  if (val === null || val === undefined) return 'NULL';
  if (typeof val === 'number') return isNaN(val) ? '0' : val.toString();
  if (typeof val === 'boolean') return val ? '1' : '0';
  const str = String(val);
  return `'${str.replace(/'/g, "''")}'`;
}

/**
 * Genera un script SQL completo con transacciones y los datos actuales
 * para ser volcado o restaurado directamente en SQLite.
 */
export function generateSqliteDump(db: KaiaDatabase): string {
  const lines: string[] = [
    '-- ====================================================================',
    `-- KAIA SQLITE DATABASE DUMP - GENERADO: ${new Date().toISOString()}`,
    '-- Compatible con SQLite3 / DB Browser for SQLite',
    '-- ====================================================================',
    KAIA_SQLITE_DDL,
    'BEGIN TRANSACTION;',
    '',
  ];

  // Company
  if (db.company) {
    const c = db.company;
    lines.push(
      `INSERT OR REPLACE INTO company (id, nombreComercial, razonSocial, cif, direccion, codigoPostal, ciudad, provincia, pais, telefono, email, web, iban, banco, swift, condicionesPago, ivaPorDefecto, retencionIRPF, cuentaBancaria, registroMercantil, condicionesDefecto, pieFacturaDefecto, moneda) VALUES (` +
        `'COMPANY_DEFAULT', ${sqlEscape(c.nombreComercial)}, ${sqlEscape(c.razonSocial)}, ${sqlEscape(c.cif)}, ${sqlEscape(c.direccion)}, ${sqlEscape(c.codigoPostal)}, ${sqlEscape(c.ciudad)}, ${sqlEscape(c.provincia)}, ${sqlEscape(c.pais)}, ${sqlEscape(c.telefono)}, ${sqlEscape(c.email)}, ${sqlEscape(c.web)}, ${sqlEscape(c.iban)}, ${sqlEscape(c.banco)}, ${sqlEscape(c.swift)}, ${sqlEscape(c.condicionesPago)}, ${c.ivaPorDefecto ?? 21}, ${c.retencionIRPF ?? 0}, ${sqlEscape(c.cuentaBancaria)}, ${sqlEscape(c.registroMercantil)}, ${sqlEscape(c.condicionesDefecto)}, ${sqlEscape(c.pieFacturaDefecto)}, ${sqlEscape(c.moneda || 'EUR')}` +
        `);`
    );
  }

  // Settings
  if (db.settings) {
    const s = db.settings;
    lines.push(
      `INSERT OR REPLACE INTO settings (id, tema, formatoFecha, moneda, autoGuardar, backupUltimaFecha, prefijoPresupuesto, prefijoFactura, prefijoProyecto, prefijoCliente, incluirAno, digitosNumero, separadorDecimal, config_json) VALUES (` +
        `'SETTINGS_DEFAULT', ${sqlEscape(s.tema)}, ${sqlEscape(s.formatoFecha)}, ${sqlEscape(s.moneda)}, ${s.autoGuardar ? 1 : 0}, ${sqlEscape(s.backupUltimaFecha)}, ${sqlEscape(s.prefijoPresupuesto)}, ${sqlEscape(s.prefijoFactura)}, ${sqlEscape(s.prefijoProyecto)}, ${sqlEscape(s.prefijoCliente)}, ${s.incluirAno ? 1 : 0}, ${s.digitosNumero || 4}, ${sqlEscape(s.separadorDecimal || ',')}, ${sqlEscape(JSON.stringify(s))}` +
        `);`
    );
  }

  // Clients
  (db.clients || []).forEach((cli) => {
    lines.push(
      `INSERT OR REPLACE INTO clients (id, nombre, apellidos, empresa, cif, email, telefono, direccion, codigoPostal, ciudad, provincia, pais, notas, estado, fechaAlta, fechaModificacion, isDemo) VALUES (` +
        `${sqlEscape(cli.id)}, ${sqlEscape(cli.nombre)}, ${sqlEscape(cli.apellidos)}, ${sqlEscape(cli.empresa)}, ${sqlEscape(cli.cif)}, ${sqlEscape(cli.email)}, ${sqlEscape(cli.telefono)}, ${sqlEscape(cli.direccion)}, ${sqlEscape(cli.codigoPostal)}, ${sqlEscape(cli.ciudad)}, ${sqlEscape(cli.provincia)}, ${sqlEscape(cli.pais)}, ${sqlEscape(cli.notas)}, ${sqlEscape(cli.estado)}, ${sqlEscape(cli.fechaAlta)}, ${sqlEscape(cli.fechaModificacion)}, ${cli.isDemo ? 1 : 0}` +
        `);`
    );
  });

  // Projects
  (db.projects || []).forEach((p) => {
    lines.push(
      `INSERT OR REPLACE INTO projects (id, titulo, clienteId, servicio, descripcion, estado, fechaInicio, fechaPrevista, importe, responsable, presupuestoId, notas, tareas_json, fechaCreacion, fechaModificacion, isDemo) VALUES (` +
        `${sqlEscape(p.id)}, ${sqlEscape(p.titulo)}, ${sqlEscape(p.clienteId)}, ${sqlEscape(p.servicio)}, ${sqlEscape(p.descripcion)}, ${sqlEscape(p.estado)}, ${sqlEscape(p.fechaInicio)}, ${sqlEscape(p.fechaPrevista)}, ${p.importe || 0}, ${sqlEscape(p.responsable)}, ${sqlEscape(p.presupuestoId)}, ${sqlEscape(p.notas)}, ${sqlEscape(JSON.stringify(p.tareas || []))}, ${sqlEscape(p.fechaCreacion)}, ${sqlEscape(p.fechaModificacion)}, ${p.isDemo ? 1 : 0}` +
        `);`
    );
  });

  // Quotes & Quote lines
  (db.quotes || []).forEach((q) => {
    const quoteIrpf = (q as { irpfTotal?: number }).irpfTotal || 0;
    lines.push(
      `INSERT OR REPLACE INTO quotes (id, clienteId, fecha, validez, estado, subtotal, descuentoTotal, ivaTotal, irpfTotal, total, condicionesPago, formaPago, plazoEntrega, revisiones, cancelacion, notas, observaciones, plantillaConfig_json, fechaCreacion, fechaModificacion, isDemo) VALUES (` +
        `${sqlEscape(q.id)}, ${sqlEscape(q.clienteId)}, ${sqlEscape(q.fecha)}, ${sqlEscape(q.validez)}, ${sqlEscape(q.estado)}, ${q.subtotal || 0}, ${q.descuentoTotal || 0}, ${q.ivaTotal || 0}, ${quoteIrpf}, ${q.total || 0}, ${sqlEscape(q.condicionesPago)}, ${sqlEscape(q.formaPago)}, ${sqlEscape(q.plazoEntrega)}, ${sqlEscape(q.revisiones)}, ${sqlEscape(q.cancelacion)}, ${sqlEscape(q.notas)}, ${sqlEscape(q.observaciones)}, ${sqlEscape(q.plantillaConfig ? JSON.stringify(q.plantillaConfig) : null)}, ${sqlEscape(q.fechaCreacion)}, ${sqlEscape(q.fechaModificacion)}, ${q.isDemo ? 1 : 0}` +
        `);`
    );

    (q.lineas || []).forEach((l, index) => {
      const lineId = `${q.id}_LINE_${l.id || index + 1}`;
      lines.push(
        `INSERT OR REPLACE INTO quote_lines (id, quoteId, descripcion, cantidad, precioUnitario, iva, descuento, totalLinea, orden) VALUES (` +
          `${sqlEscape(lineId)}, ${sqlEscape(q.id)}, ${sqlEscape(l.descripcion)}, ${l.cantidad || 1}, ${l.precioUnitario || 0}, ${l.iva || 21}, ${l.descuento || 0}, ${(l.cantidad || 1) * (l.precioUnitario || 0)}, ${index}` +
          `);`
      );
    });
  });

  // Invoices, Lines & Payments
  (db.invoices || []).forEach((inv) => {
    const pieFactura = (inv as { pieFactura?: string }).pieFactura || inv.plantillaConfig?.notasPiePersonalizadas || '';
    lines.push(
      `INSERT OR REPLACE INTO invoices (id, clienteId, presupuestoId, proyectoId, fechaEmision, fechaVencimiento, formaPago, metodoPago, cuentaBancaria, baseImponible, ivaTotal, irpfTotal, total, importePagado, importePendiente, estado, notas, pieFactura, plantillaConfig_json, fechaCreacion, fechaModificacion, isDemo) VALUES (` +
        `${sqlEscape(inv.id)}, ${sqlEscape(inv.clienteId)}, ${sqlEscape(inv.presupuestoId)}, ${sqlEscape(inv.proyectoId)}, ${sqlEscape(inv.fechaEmision)}, ${sqlEscape(inv.fechaVencimiento)}, ${sqlEscape(inv.formaPago)}, ${sqlEscape(inv.metodoPago)}, ${sqlEscape(inv.cuentaBancaria)}, ${inv.baseImponible || 0}, ${inv.ivaTotal || 0}, ${inv.irpfTotal || 0}, ${inv.total || 0}, ${inv.importePagado || 0}, ${inv.importePendiente || 0}, ${sqlEscape(inv.estado)}, ${sqlEscape(inv.notas)}, ${sqlEscape(pieFactura)}, ${sqlEscape(inv.plantillaConfig ? JSON.stringify(inv.plantillaConfig) : null)}, ${sqlEscape(inv.fechaCreacion)}, ${sqlEscape(inv.fechaModificacion)}, ${inv.isDemo ? 1 : 0}` +
        `);`
    );

    (inv.lineas || []).forEach((l, index) => {
      const lineId = `${inv.id}_LINE_${l.id || index + 1}`;
      lines.push(
        `INSERT OR REPLACE INTO invoice_lines (id, invoiceId, descripcion, cantidad, precioUnitario, iva, descuento, totalLinea, orden) VALUES (` +
          `${sqlEscape(lineId)}, ${sqlEscape(inv.id)}, ${sqlEscape(l.descripcion)}, ${l.cantidad || 1}, ${l.precioUnitario || 0}, ${l.iva || 21}, ${l.descuento || 0}, ${(l.cantidad || 1) * (l.precioUnitario || 0)}, ${index}` +
          `);`
      );
    });

    (inv.pagos || []).forEach((pay) => {
      lines.push(
        `INSERT OR REPLACE INTO invoice_payments (id, invoiceId, fecha, importe, metodo, referencia, notas) VALUES (` +
          `${sqlEscape(pay.id)}, ${sqlEscape(inv.id)}, ${sqlEscape(pay.fecha)}, ${pay.importe || 0}, ${sqlEscape(pay.metodo)}, ${sqlEscape(pay.referencia)}, ${sqlEscape(pay.notas)}` +
          `);`
      );
    });
  });

  // Finances
  (db.finances || []).forEach((f) => {
    lines.push(
      `INSERT OR REPLACE INTO finances (id, fecha, tipo, categoria, descripcion, importe, metodo, estado, clienteId, proyectoId, facturaId, fechaCreacion, isDemo) VALUES (` +
        `${sqlEscape(f.id)}, ${sqlEscape(f.fecha)}, ${sqlEscape(f.tipo)}, ${sqlEscape(f.categoria)}, ${sqlEscape(f.descripcion)}, ${f.importe || 0}, ${sqlEscape(f.metodo)}, ${sqlEscape(f.estado)}, ${sqlEscape(f.clienteId)}, ${sqlEscape(f.proyectoId)}, ${sqlEscape(f.facturaId)}, ${sqlEscape(f.fechaCreacion)}, ${f.isDemo ? 1 : 0}` +
        `);`
    );
  });

  // Documents
  (db.documents || []).forEach((d) => {
    lines.push(
      `INSERT OR REPLACE INTO documents (id, nombre, categoria, tamano, tipo, fechaSubida, clienteId, proyectoId, rutaLocal, isDemo) VALUES (` +
        `${sqlEscape(d.id)}, ${sqlEscape(d.nombre)}, ${sqlEscape(d.categoria)}, ${sqlEscape(d.tamano)}, ${sqlEscape(d.tipo)}, ${sqlEscape(d.fechaSubida)}, ${sqlEscape(d.clienteId)}, ${sqlEscape(d.proyectoId)}, ${sqlEscape(d.url || d.nombre)}, ${d.isDemo ? 1 : 0}` +
        `);`
    );
  });

  // Leads
  (db.leads || []).forEach((l) => {
    lines.push(
      `INSERT OR REPLACE INTO commercial_leads (id, empresa, contacto, email, telefono, origen, servicioInteres, estado, valorEstimado, fechaContacto, proximoSeguimiento, notas, fechaCreacion, isDemo) VALUES (` +
        `${sqlEscape(l.id)}, ${sqlEscape(l.empresa)}, ${sqlEscape(l.contacto)}, ${sqlEscape(l.email)}, ${sqlEscape(l.telefono)}, ${sqlEscape(l.origen)}, ${sqlEscape(l.servicioInteres)}, ${sqlEscape(l.estado)}, ${l.valorEstimado || 0}, ${sqlEscape(l.fechaContacto)}, ${sqlEscape(l.proximoSeguimiento)}, ${sqlEscape(l.notas)}, ${sqlEscape(l.fechaCreacion)}, ${l.isDemo ? 1 : 0}` +
        `);`
    );
  });

  // Suppliers
  (db.suppliers || []).forEach((s) => {
    lines.push(
      `INSERT OR REPLACE INTO suppliers (id, proveedor, cif, contacto, email, telefono, web, servicio, condiciones, estado, notas, fechaCreacion, fechaModificacion, isDemo) VALUES (` +
        `${sqlEscape(s.id)}, ${sqlEscape(s.proveedor)}, ${sqlEscape(s.cif)}, ${sqlEscape(s.contacto)}, ${sqlEscape(s.email)}, ${sqlEscape(s.telefono)}, ${sqlEscape(s.web)}, ${sqlEscape(s.servicio)}, ${sqlEscape(s.condiciones)}, ${sqlEscape(s.estado)}, ${sqlEscape(s.notas)}, ${sqlEscape(s.fechaCreacion)}, ${sqlEscape(s.fechaModificacion)}, ${s.isDemo ? 1 : 0}` +
        `);`
    );
  });

  // Products
  (db.products || []).forEach((p) => {
    lines.push(
      `INSERT OR REPLACE INTO products (id, nombre, referencia, categoria, descripcion, precio, iva, stock, stockMinimo, proveedorId, estado, fechaCreacion, fechaModificacion, isDemo) VALUES (` +
        `${sqlEscape(p.id)}, ${sqlEscape(p.nombre)}, ${sqlEscape(p.referencia)}, ${sqlEscape(p.categoria)}, ${sqlEscape(p.descripcion)}, ${p.precio || 0}, ${p.iva || 21}, ${p.stock || 0}, ${p.stockMinimo || 0}, ${sqlEscape(p.proveedorId)}, ${sqlEscape(p.estado)}, ${sqlEscape(p.fechaCreacion)}, ${sqlEscape(p.fechaModificacion)}, ${p.isDemo ? 1 : 0}` +
        `);`
    );
  });

  // Activities
  (db.activities || []).forEach((a) => {
    lines.push(
      `INSERT OR REPLACE INTO activities (id, fecha, descripcion, tipo, entidadId, targetView, targetId) VALUES (` +
        `${sqlEscape(a.id)}, ${sqlEscape(a.fecha)}, ${sqlEscape(a.descripcion || a.accion || '')}, ${sqlEscape(a.tipo || 'sistema')}, ${sqlEscape(a.entidadId)}, ${sqlEscape(a.targetView)}, ${sqlEscape(a.targetId)}` +
        `);`
    );
  });

  lines.push('COMMIT;');
  lines.push('');
  return lines.join('\n');
}
