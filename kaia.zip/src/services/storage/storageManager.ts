import {
  ActivityLog,
  Client,
  CommercialLead,
  CompanyProfile,
  DocumentItem,
  FinanceMovement,
  Invoice,
  KaiaDatabase,
  PaymentRecord,
  Product,
  Project,
  Quote,
  Supplier,
  ViewMode,
} from '../../types';
import { getTodayISO } from '../../utils/formatters';
import { defaultCompany, defaultSettings, initialDemoData, STORAGE_KEY } from './defaults';
import { ElectronBridge } from './electronBridge';
import { generateSqliteDump } from './sqliteSchema';
import {
  BackupResult,
  DatabaseIntegrityReport,
  DesktopEnvironmentInfo,
  StorageEngineType,
} from './types';

export class StorageManager {
  private db: KaiaDatabase;
  private listeners: (() => void)[] = [];
  private cachedEnvInfo: DesktopEnvironmentInfo | null = null;
  private isInitialized = false;

  constructor() {
    this.db = this.loadInitial();
    this.initDesktopBridge();
  }

  /**
   * Carga inicial síncrona para que la interfaz React renderice al instante
   */
  private loadInitial(): KaiaDatabase {
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        const stored = localStorage.getItem(STORAGE_KEY);
        if (stored) {
          const parsed = JSON.parse(stored) as KaiaDatabase;
          if (parsed.company && Array.isArray(parsed.clients) && Array.isArray(parsed.invoices)) {
            return {
              ...initialDemoData,
              ...parsed,
              company: { ...defaultCompany, ...parsed.company },
              settings: { ...defaultSettings, ...parsed.settings },
            };
          }
        }
      }
    } catch (e) {
      console.warn('Almacenamiento local temporal no disponible:', e);
    }
    return { ...initialDemoData };
  }

  /**
   * Conexión asíncrona con el proceso Electron si estamos en entorno de escritorio
   */
  private async initDesktopBridge(): Promise<void> {
    if (this.isInitialized) return;
    this.isInitialized = true;

    try {
      if (ElectronBridge.isElectron()) {
        this.cachedEnvInfo = await ElectronBridge.getEnvironment();
        const desktopDb = await ElectronBridge.readDatabase();
        if (desktopDb && Array.isArray(desktopDb.clients)) {
          this.db = {
            ...initialDemoData,
            ...desktopDb,
            company: { ...defaultCompany, ...(desktopDb.company || {}) },
            settings: { ...defaultSettings, ...(desktopDb.settings || {}) },
          };
          this.notify();
        } else {
          // Si el archivo SQLite / JSON está vacío, persistimos los datos actuales al entorno de escritorio
          await ElectronBridge.writeDatabase(this.db);
        }
      } else {
        this.cachedEnvInfo = await ElectronBridge.getEnvironment();
      }
    } catch (err) {
      console.error('Error inicializando el motor de almacenamiento de escritorio:', err);
    }
  }

  /**
   * Persistencia dual: guarda en localStorage y de inmediato en SQLite/archivos si está en Electron
   */
  private persist(db: KaiaDatabase): void {
    this.db = db;

    // 1. Guardado en navegador / caché local
    try {
      if (typeof window !== 'undefined' && window.localStorage) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(db));
      }
    } catch (e) {
      console.warn('Error en persistencia de navegador:', e);
    }

    // 2. Si estamos en Electron, persistir atómicamente a database/kaia.sqlite y mirror JSON
    if (ElectronBridge.isElectron()) {
      ElectronBridge.writeDatabase(db).catch((err) => {
        console.error('Error guardando en base de datos local SQLite:', err);
      });
    }

    this.notify();
  }

  public subscribe(listener: () => void): () => void {
    this.listeners.push(listener);
    return () => {
      this.listeners = this.listeners.filter((l) => l !== listener);
    };
  }

  private notify(): void {
    this.listeners.forEach((l) => l());
  }

  // --- INFORMACIÓN DE ENTORNO Y PORTABILIDAD ---

  public getStorageEngine(): StorageEngineType {
    return ElectronBridge.isElectron() ? 'electron-sqlite' : 'browser-localstorage';
  }

  public isDesktop(): boolean {
    return ElectronBridge.isElectron();
  }

  public async getEnvironmentInfo(): Promise<DesktopEnvironmentInfo> {
    const env = await ElectronBridge.getEnvironment();
    this.cachedEnvInfo = env;
    return env;
  }

  public getCachedEnvironmentInfo(): DesktopEnvironmentInfo | null {
    return this.cachedEnvInfo;
  }

  public getSqliteSchemaScript(): string {
    return generateSqliteDump(this.db);
  }

  public async createPortableBackup(note?: string): Promise<BackupResult> {
    const timestamp = new Date().toISOString();

    if (ElectronBridge.isElectron()) {
      return await ElectronBridge.createBackup(note);
    }

    // En navegador, simular backup y registrar actividad
    this.logActivity('Copia de seguridad local generada', 'sistema');
    return {
      success: true,
      fileName: `KAIA_backup_${timestamp.split('T')[0]}_manual.json`,
      filePath: './data/backups',
      timestamp,
    };
  }

  public async openPortableFolder(type: 'database' | 'documents' | 'backups' | 'exports' | 'base'): Promise<boolean> {
    return await ElectronBridge.openFolder(type);
  }

  public async saveExportToPortableFolder(
    fileName: string,
    data: string | Uint8Array,
    mimeType?: string
  ): Promise<{ success: boolean; filePath?: string }> {
    if (ElectronBridge.isElectron()) {
      const res = await ElectronBridge.saveExportFile(fileName, data, mimeType);
      return { success: res.success, filePath: res.filePath };
    }
    return { success: false };
  }

  public verifyDatabaseIntegrity(): DatabaseIntegrityReport {
    const recordsCount = {
      clients: this.db.clients?.length || 0,
      projects: this.db.projects?.length || 0,
      quotes: this.db.quotes?.length || 0,
      invoices: this.db.invoices?.length || 0,
      finances: this.db.finances?.length || 0,
      documents: this.db.documents?.length || 0,
      leads: this.db.leads?.length || 0,
      suppliers: this.db.suppliers?.length || 0,
      products: this.db.products?.length || 0,
      activities: this.db.activities?.length || 0,
    };

    const hasCompany = Boolean(this.db.company?.razonSocial && this.db.company?.cif);
    const hasSettings = Boolean(this.db.settings?.moneda);

    return {
      isValid: hasCompany && hasSettings,
      tablesCount: 12,
      recordsCount,
      checkedAt: new Date().toISOString(),
      storageEngine: this.getStorageEngine(),
      portableReady: true,
    };
  }

  // --- ACCESO Y CONSULTA DE LA BASE DE DATOS ---

  public getDatabase(): KaiaDatabase {
    if (!this.db.commercial) {
      this.db.commercial = this.db.leads;
    }
    this.db.company = { ...defaultCompany, ...(this.db.company || {}) };
    this.db.settings = { ...defaultSettings, ...(this.db.settings || {}) };
    return this.db;
  }

  public getActivityLogs(): ActivityLog[] {
    return (this.db.activities || []).map((a) => ({
      ...a,
      accion: a.descripcion || a.accion || 'Actividad registrada',
      detalles: a.entidadId ? `ID: ${a.entidadId}` : a.tipo,
      usuario: 'Administrador KAIA',
      entidad: (a.tipo || 'SISTEMA').toUpperCase(),
      timestamp: a.fecha || a.timestamp || getTodayISO(),
    }));
  }

  public clearActivityLogs(): void {
    this.persist({ ...this.db, activities: [] });
  }

  public exportDatabaseJSON(): string {
    return this.exportBackup();
  }

  public importDatabaseJSON(jsonStr: string): boolean {
    return this.restoreBackup(jsonStr);
  }

  public resetToInitialData(): void {
    this.resetToDemo();
  }

  public saveOpportunity(opp: CommercialLead): void {
    this.saveLead(opp);
  }

  public deleteOpportunity(id: string): void {
    this.deleteLead(id);
  }

  // --- REGISTRO DE ACTIVIDAD ---
  public logActivity(
    descripcion: string,
    tipo: ActivityLog['tipo'],
    entidadId?: string,
    targetView?: ViewMode,
    targetId?: string
  ): void {
    const now = new Date();
    const dateStr = `${getTodayISO()} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;
    const newLog: ActivityLog = {
      id: `ACT-${Date.now()}`,
      fecha: dateStr,
      descripcion,
      tipo,
      entidadId,
      targetView,
      targetId,
    };
    const updatedActivities = [newLog, ...(this.db.activities || [])].slice(0, 100);
    this.persist({
      ...this.db,
      activities: updatedActivities,
    });
  }

  // --- CLIENTES ---
  public getClients(): Client[] {
    return this.db.clients || [];
  }

  public getClient(id: string): Client | undefined {
    return (this.db.clients || []).find((c) => c.id === id);
  }

  public saveClient(client: Client): void {
    const exists = (this.db.clients || []).some((c) => c.id === client.id);
    let updatedClients: Client[];
    if (exists) {
      updatedClients = this.db.clients.map((c) => (c.id === client.id ? client : c));
      this.logActivity(`Cliente ${client.empresa || client.nombre} actualizado`, 'cliente', client.id, 'client-detail', client.id);
    } else {
      updatedClients = [client, ...(this.db.clients || [])];
      this.logActivity(`Cliente ${client.empresa || client.nombre} creado`, 'cliente', client.id, 'client-detail', client.id);
    }
    this.persist({ ...this.db, clients: updatedClients });
  }

  public deleteClient(id: string): void {
    const client = this.getClient(id);
    const updated = (this.db.clients || []).filter((c) => c.id !== id);
    this.logActivity(`Cliente ${client?.empresa || id} eliminado`, 'cliente');
    this.persist({ ...this.db, clients: updated });
  }

  // --- PROYECTOS ---
  public getProjects(): Project[] {
    return this.db.projects || [];
  }

  public getProject(id: string): Project | undefined {
    return (this.db.projects || []).find((p) => p.id === id);
  }

  public saveProject(project: Project): void {
    const exists = (this.db.projects || []).some((p) => p.id === project.id);
    let updated: Project[];
    if (exists) {
      updated = this.db.projects.map((p) => (p.id === project.id ? project : p));
      this.logActivity(`Proyecto ${project.titulo} actualizado`, 'proyecto', project.id, 'project-detail', project.id);
    } else {
      updated = [project, ...(this.db.projects || [])];
      this.logActivity(`Proyecto ${project.titulo} creado`, 'proyecto', project.id, 'project-detail', project.id);
    }
    this.persist({ ...this.db, projects: updated });
  }

  public deleteProject(id: string): void {
    const p = this.getProject(id);
    const updated = (this.db.projects || []).filter((item) => item.id !== id);
    this.logActivity(`Proyecto ${p?.titulo || id} eliminado`, 'proyecto');
    this.persist({ ...this.db, projects: updated });
  }

  // --- PRESUPUESTOS ---
  public getQuotes(): Quote[] {
    return this.db.quotes || [];
  }

  public getQuote(id: string): Quote | undefined {
    return (this.db.quotes || []).find((q) => q.id === id);
  }

  public saveQuote(quote: Quote): void {
    const exists = (this.db.quotes || []).some((q) => q.id === quote.id);
    let updated: Quote[];
    if (exists) {
      updated = this.db.quotes.map((q) => (q.id === quote.id ? quote : q));
      this.logActivity(`Presupuesto ${quote.id} actualizado`, 'presupuesto', quote.id, 'quote-detail', quote.id);
    } else {
      updated = [quote, ...(this.db.quotes || [])];
      this.logActivity(`Presupuesto ${quote.id} generado`, 'presupuesto', quote.id, 'quote-detail', quote.id);
    }
    this.persist({ ...this.db, quotes: updated });
  }

  public deleteQuote(id: string): void {
    const updated = (this.db.quotes || []).filter((q) => q.id !== id);
    this.logActivity(`Presupuesto ${id} eliminado`, 'presupuesto');
    this.persist({ ...this.db, quotes: updated });
  }

  // --- FACTURAS ---
  public getInvoices(): Invoice[] {
    return this.db.invoices || [];
  }

  public getInvoice(id: string): Invoice | undefined {
    return (this.db.invoices || []).find((i) => i.id === id);
  }

  public saveInvoice(invoice: Invoice): void {
    const exists = (this.db.invoices || []).some((i) => i.id === invoice.id);
    let updated: Invoice[];
    if (exists) {
      updated = this.db.invoices.map((i) => (i.id === invoice.id ? invoice : i));
      this.logActivity(`Factura ${invoice.id} actualizada`, 'factura', invoice.id, 'invoice-detail', invoice.id);
    } else {
      updated = [invoice, ...(this.db.invoices || [])];
      this.logActivity(`Factura ${invoice.id} emitida`, 'factura', invoice.id, 'invoice-detail', invoice.id);
    }
    this.persist({ ...this.db, invoices: updated });
  }

  public registerPayment(invoiceId: string, payment: PaymentRecord): void {
    const invoice = this.getInvoice(invoiceId);
    if (!invoice) return;

    const updatedPagos = [...(invoice.pagos || []), payment];
    const totalPagado = updatedPagos.reduce((acc, p) => acc + p.importe, 0);
    const pendiente = Math.max(0, invoice.total - totalPagado);

    let nuevoEstado = invoice.estado;
    if (pendiente <= 0.01) {
      nuevoEstado = 'Pagada';
    } else if (totalPagado > 0) {
      nuevoEstado = 'Parcial';
    }

    const updatedInvoice: Invoice = {
      ...invoice,
      pagos: updatedPagos,
      importePagado: totalPagado,
      importePendiente: pendiente,
      estado: nuevoEstado,
      fechaModificacion: getTodayISO(),
    };

    // Registrar también movimiento financiero automático en tesorería
    const client = this.getClient(invoice.clienteId);
    const nuevoMovimiento: FinanceMovement = {
      id: `MOV-${Date.now().toString().slice(-4)}`,
      fecha: payment.fecha,
      tipo: 'Ingreso',
      categoria: 'Cobro de Facturas',
      descripcion: `Cobro ${invoice.id} (${client?.empresa || client?.nombre || 'Cliente'}) - Ref: ${payment.referencia || 'S/R'}`,
      importe: payment.importe,
      metodo: payment.metodo,
      estado: 'Completado',
      clienteId: invoice.clienteId,
      proyectoId: invoice.proyectoId,
      facturaId: invoice.id,
      fechaCreacion: payment.fecha,
    };

    const updatedFinances = [nuevoMovimiento, ...(this.db.finances || [])];
    const updatedInvoices = (this.db.invoices || []).map((i) => (i.id === invoiceId ? updatedInvoice : i));

    this.logActivity(
      `Pago de ${payment.importe.toFixed(2)} € registrado para ${invoice.id}`,
      'pago',
      invoice.id,
      'invoice-detail',
      invoice.id
    );

    this.persist({
      ...this.db,
      invoices: updatedInvoices,
      finances: updatedFinances,
    });
  }

  public deleteInvoice(id: string): void {
    const updated = (this.db.invoices || []).filter((i) => i.id !== id);
    this.logActivity(`Factura ${id} eliminada`, 'factura');
    this.persist({ ...this.db, invoices: updated });
  }

  // --- FINANZAS ---
  public getFinances(): FinanceMovement[] {
    return this.db.finances || [];
  }

  public saveFinance(movement: FinanceMovement): void {
    const exists = (this.db.finances || []).some((m) => m.id === movement.id);
    let updated: FinanceMovement[];
    if (exists) {
      updated = (this.db.finances || []).map((m) => (m.id === movement.id ? movement : m));
    } else {
      updated = [movement, ...(this.db.finances || [])];
    }
    this.logActivity(`Movimiento financiero (${movement.tipo}): ${movement.descripcion}`, 'finanzas');
    this.persist({ ...this.db, finances: updated });
  }

  public deleteFinance(id: string): void {
    const updated = (this.db.finances || []).filter((m) => m.id !== id);
    this.logActivity(`Movimiento financiero ${id} eliminado`, 'finanzas');
    this.persist({ ...this.db, finances: updated });
  }

  // --- DOCUMENTOS ---
  public getDocuments(): DocumentItem[] {
    return this.db.documents || [];
  }

  public saveDocument(doc: DocumentItem): void {
    const exists = (this.db.documents || []).some((d) => d.id === doc.id);
    let updated: DocumentItem[];
    if (exists) {
      updated = (this.db.documents || []).map((d) => (d.id === doc.id ? doc : d));
    } else {
      updated = [doc, ...(this.db.documents || [])];
    }
    this.logActivity(`Documento añadido: ${doc.nombre}`, 'documento');
    this.persist({ ...this.db, documents: updated });
  }

  public deleteDocument(id: string): void {
    const doc = (this.db.documents || []).find((d) => d.id === id);
    const updated = (this.db.documents || []).filter((d) => d.id !== id);
    this.logActivity(`Documento eliminado: ${doc?.nombre || id}`, 'documento');
    this.persist({ ...this.db, documents: updated });
  }

  // --- COMERCIAL (LEADS) ---
  public getLeads(): CommercialLead[] {
    return this.db.leads || [];
  }

  public getLead(id: string): CommercialLead | undefined {
    return (this.db.leads || []).find((l) => l.id === id);
  }

  public saveLead(lead: CommercialLead): void {
    const exists = (this.db.leads || []).some((l) => l.id === lead.id);
    let updated: CommercialLead[];
    if (exists) {
      updated = (this.db.leads || []).map((l) => (l.id === lead.id ? lead : l));
    } else {
      updated = [lead, ...(this.db.leads || [])];
    }
    this.logActivity(`Oportunidad comercial ${lead.empresa} (${lead.estado}) actualizada`, 'comercial');
    this.persist({ ...this.db, leads: updated });
  }

  public deleteLead(id: string): void {
    const l = this.getLead(id);
    const updated = (this.db.leads || []).filter((item) => item.id !== id);
    this.logActivity(`Oportunidad ${l?.empresa || id} eliminada`, 'comercial');
    this.persist({ ...this.db, leads: updated });
  }

  // --- PROVEEDORES ---
  public getSuppliers(): Supplier[] {
    return this.db.suppliers || [];
  }

  public getSupplier(id: string): Supplier | undefined {
    return (this.db.suppliers || []).find((s) => s.id === id);
  }

  public saveSupplier(supplier: Supplier): void {
    const exists = (this.db.suppliers || []).some((s) => s.id === supplier.id);
    let updated: Supplier[];
    if (exists) {
      updated = (this.db.suppliers || []).map((s) => (s.id === supplier.id ? supplier : s));
    } else {
      updated = [supplier, ...(this.db.suppliers || [])];
    }
    this.logActivity(`Proveedor ${supplier.proveedor} guardado`, 'sistema');
    this.persist({ ...this.db, suppliers: updated });
  }

  public deleteSupplier(id: string): void {
    const s = this.getSupplier(id);
    const updated = (this.db.suppliers || []).filter((item) => item.id !== id);
    this.logActivity(`Proveedor ${s?.proveedor || id} eliminado`, 'sistema');
    this.persist({ ...this.db, suppliers: updated });
  }

  // --- PRODUCTOS ---
  public getProducts(): Product[] {
    return this.db.products || [];
  }

  public getProduct(id: string): Product | undefined {
    return (this.db.products || []).find((p) => p.id === id);
  }

  public saveProduct(product: Product): void {
    const exists = (this.db.products || []).some((p) => p.id === product.id);
    let updated: Product[];
    if (exists) {
      updated = (this.db.products || []).map((p) => (p.id === product.id ? product : p));
    } else {
      updated = [product, ...(this.db.products || [])];
    }
    this.logActivity(`Producto ${product.nombre} guardado`, 'sistema');
    this.persist({ ...this.db, products: updated });
  }

  public deleteProduct(id: string): void {
    const p = this.getProduct(id);
    const updated = (this.db.products || []).filter((item) => item.id !== id);
    this.logActivity(`Producto ${p?.nombre || id} eliminado`, 'sistema');
    this.persist({ ...this.db, products: updated });
  }

  // --- EMPRESA Y CONFIGURACIÓN ---
  public getCompany(): CompanyProfile {
    return { ...defaultCompany, ...(this.db.company || {}) };
  }

  public saveCompany(company: CompanyProfile): void {
    this.logActivity('Datos de empresa KAIA actualizados', 'sistema');
    this.persist({ ...this.db, company });
  }

  public getSettings(): KaiaDatabase['settings'] {
    return { ...defaultSettings, ...(this.db.settings || {}) };
  }

  public saveSettings(settings: KaiaDatabase['settings']): void {
    this.persist({ ...this.db, settings });
  }

  // --- COPIAS DE SEGURIDAD Y RESTAURACIÓN ---
  public exportBackup(): string {
    const payload = {
      version: '2.0-portable',
      exportedAt: new Date().toISOString(),
      app: 'KAIA Business Management System',
      storageEngine: this.getStorageEngine(),
      data: this.db,
    };
    return JSON.stringify(payload, null, 2);
  }

  public restoreBackup(jsonString: string): boolean {
    try {
      const parsed = JSON.parse(jsonString);
      const data = parsed.data || parsed;
      if (data.company && Array.isArray(data.clients) && Array.isArray(data.invoices)) {
        this.persist(data);
        this.logActivity('Copia de seguridad restaurada con éxito', 'sistema');
        return true;
      }
      return false;
    } catch (e) {
      console.error('Error restaurando copia de seguridad:', e);
      return false;
    }
  }

  public resetToClean(): void {
    const cleanDb: KaiaDatabase = {
      company: defaultCompany,
      settings: {
        tema: 'claro',
        formatoFecha: 'DD/MM/YYYY',
        moneda: 'EUR',
        autoGuardar: true,
      },
      clients: [],
      projects: [],
      quotes: [],
      invoices: [],
      finances: [],
      documents: [],
      leads: [],
      suppliers: [],
      products: [],
      activities: [
        {
          id: 'ACT-0000',
          fecha: `${getTodayISO()} 09:00`,
          descripcion: 'Base de datos de KAIA inicializada desde cero',
          tipo: 'sistema',
        },
      ],
    };
    this.persist(cleanDb);
  }

  public resetToDemo(): void {
    this.persist(initialDemoData);
  }
}

export const storageService = new StorageManager();
