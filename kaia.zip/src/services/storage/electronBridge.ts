import { KaiaDatabase } from '../../types';
import { BackupResult, DesktopEnvironmentInfo, PortableDirectoryStructure } from './types';

// Default virtual/fallback paths for browser and development mode
export const DEFAULT_DEV_PATHS: PortableDirectoryStructure = {
  baseDir: './data',
  databaseDir: './data/database',
  documentsDir: './data/documents',
  backupsDir: './data/backups',
  exportsDir: './data/exports',
  dbSqlitePath: './data/database/kaia.sqlite',
  dbJsonPath: './data/database/kaia-database.json',
  schemaSqlPath: './data/database/kaia_schema.sql',
};

export const DEFAULT_PORTABLE_WINDOWS_PATHS: PortableDirectoryStructure = {
  baseDir: 'E:\\KAIA',
  databaseDir: 'E:\\KAIA\\database',
  documentsDir: 'E:\\KAIA\\documents',
  backupsDir: 'E:\\KAIA\\backups',
  exportsDir: 'E:\\KAIA\\exports',
  dbSqlitePath: 'E:\\KAIA\\database\\kaia.sqlite',
  dbJsonPath: 'E:\\KAIA\\database\\kaia-database.json',
  schemaSqlPath: 'E:\\KAIA\\database\\kaia_schema.sql',
};

// Global typing extension
declare global {
  interface Window {
    kaiaDesktop?: {
      isDesktop: boolean;
      getEnvironment: () => Promise<DesktopEnvironmentInfo>;
      readDatabase: () => Promise<KaiaDatabase | null>;
      writeDatabase: (db: KaiaDatabase) => Promise<boolean>;
      createBackup: (note?: string) => Promise<BackupResult>;
      executeSql: (sql: string, params?: any[]) => Promise<{ success: boolean; rows?: any[]; error?: string }>;
      openFolder: (type: 'database' | 'documents' | 'backups' | 'exports' | 'base') => Promise<boolean>;
      saveExportFile: (fileName: string, data: string | Uint8Array, mimeType?: string) => Promise<{ success: boolean; filePath: string; error?: string }>;
      saveDocumentFile: (fileName: string, data: string | Uint8Array) => Promise<{ success: boolean; filePath: string; error?: string }>;
      windowControl: (action: 'minimize' | 'maximize' | 'close') => Promise<void>;
    };
  }
}

export class ElectronBridge {
  public static isElectron(): boolean {
    return typeof window !== 'undefined' && Boolean(window.kaiaDesktop?.isDesktop);
  }

  public static async getEnvironment(): Promise<DesktopEnvironmentInfo> {
    if (this.isElectron() && window.kaiaDesktop?.getEnvironment) {
      try {
        return await window.kaiaDesktop.getEnvironment();
      } catch (e) {
        console.warn('Error fetching Electron environment:', e);
      }
    }

    // Fallback simulation in browser preview
    return {
      isElectron: false,
      isPortable: false,
      isDev: true,
      platform: 'browser',
      storageEngine: 'browser-localstorage',
      paths: DEFAULT_DEV_PATHS,
      counts: {
        backups: 0,
        documents: 0,
        exports: 0,
      },
      lastSync: new Date().toISOString(),
    };
  }

  public static async readDatabase(): Promise<KaiaDatabase | null> {
    if (this.isElectron() && window.kaiaDesktop?.readDatabase) {
      try {
        return await window.kaiaDesktop.readDatabase();
      } catch (e) {
        console.error('Error reading database via Electron desktop bridge:', e);
      }
    }
    return null;
  }

  public static async writeDatabase(db: KaiaDatabase): Promise<boolean> {
    if (this.isElectron() && window.kaiaDesktop?.writeDatabase) {
      try {
        return await window.kaiaDesktop.writeDatabase(db);
      } catch (e) {
        console.error('Error writing database via Electron desktop bridge:', e);
        return false;
      }
    }
    return false;
  }

  public static async createBackup(note?: string): Promise<BackupResult> {
    const timestamp = new Date().toISOString();
    if (this.isElectron() && window.kaiaDesktop?.createBackup) {
      try {
        return await window.kaiaDesktop.createBackup(note);
      } catch (e) {
        return {
          success: false,
          error: String(e),
          timestamp,
        };
      }
    }

    return {
      success: false,
      error: 'Modo escritorio no disponible (ejecutándose en navegador)',
      timestamp,
    };
  }

  public static async openFolder(type: 'database' | 'documents' | 'backups' | 'exports' | 'base'): Promise<boolean> {
    if (this.isElectron() && window.kaiaDesktop?.openFolder) {
      try {
        return await window.kaiaDesktop.openFolder(type);
      } catch (e) {
        console.error(`Error opening folder ${type}:`, e);
        return false;
      }
    }
    return false;
  }

  public static async saveExportFile(
    fileName: string,
    data: string | Uint8Array,
    mimeType?: string
  ): Promise<{ success: boolean; filePath?: string; error?: string }> {
    if (this.isElectron() && window.kaiaDesktop?.saveExportFile) {
      try {
        return await window.kaiaDesktop.saveExportFile(fileName, data, mimeType);
      } catch (e) {
        return { success: false, error: String(e) };
      }
    }
    return { success: false, error: 'Bridge Electron no activo' };
  }
}
