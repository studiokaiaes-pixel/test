-- ====================================================================
-- KAIA BUSINESS MANAGEMENT SYSTEM - ESQUEMA RELACIONAL SQLITE
-- Archivo: database/kaia.sqlite
-- Compatible con SQLite 3.x y SQLite portable para Windows
-- ====================================================================

PRAGMA foreign_keys = ON;
PRAGMA encoding = 'UTF-8';
PRAGMA journal_mode = WAL;

-- 1. EMPRESA Y CONFIGURACIÓN FISCAL
CREATE TABLE IF NOT EXISTS company (
  id TEXT PRIMARY KEY DEFAULT 'COMPANY_DEFAULT',
  nombreComercial TEXT NOT NULL,
  razonSocial TEXT NOT NULL,
  cif TEXT NOT NULL,
  direccion TEXT,
  codigoPostal TEXT,
  ciudad TEXT,
  provincia TEXT,
  pais TEXT DEFAULT 'España',
  telefono TEXT,
  email TEXT,
  web TEXT,
  iban TEXT,
  banco TEXT,
  swift TEXT,
  condicionesPago TEXT,
  ivaPorDefecto REAL DEFAULT 21,
  retencionIRPF REAL DEFAULT 0,
  cuentaBancaria TEXT,
  registroMercantil TEXT,
  condicionesDefecto TEXT,
  pieFacturaDefecto TEXT,
  moneda TEXT DEFAULT 'EUR',
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 2. CONFIGURACIÓN DEL SISTEMA
CREATE TABLE IF NOT EXISTS settings (
  id TEXT PRIMARY KEY DEFAULT 'SETTINGS_DEFAULT',
  tema TEXT DEFAULT 'claro',
  formatoFecha TEXT DEFAULT 'DD/MM/YYYY',
  moneda TEXT DEFAULT 'EUR',
  autoGuardar INTEGER DEFAULT 1,
  backupUltimaFecha TEXT,
  prefijoPresupuesto TEXT DEFAULT 'PRE',
  prefijoFactura TEXT DEFAULT 'FAC',
  prefijoProyecto TEXT DEFAULT 'PRO',
  prefijoCliente TEXT DEFAULT 'CLI',
  incluirAno INTEGER DEFAULT 1,
  digitosNumero INTEGER DEFAULT 4,
  separadorDecimal TEXT DEFAULT ',',
  config_json TEXT,
  updated_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 3. CLIENTES
CREATE TABLE IF NOT EXISTS clients (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  apellidos TEXT,
  empresa TEXT,
  cif TEXT,
  email TEXT,
  telefono TEXT,
  direccion TEXT,
  codigoPostal TEXT,
  ciudad TEXT,
  provincia TEXT,
  pais TEXT DEFAULT 'España',
  notas TEXT,
  estado TEXT DEFAULT 'Activo',
  fechaAlta TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

CREATE INDEX IF NOT EXISTS idx_clients_empresa ON clients(empresa);
CREATE INDEX IF NOT EXISTS idx_clients_cif ON clients(cif);
CREATE INDEX IF NOT EXISTS idx_clients_estado ON clients(estado);

-- 4. PROYECTOS
CREATE TABLE IF NOT EXISTS projects (
  id TEXT PRIMARY KEY,
  titulo TEXT NOT NULL,
  clienteId TEXT NOT NULL,
  servicio TEXT,
  descripcion TEXT,
  estado TEXT DEFAULT 'En curso',
  fechaInicio TEXT,
  fechaPrevista TEXT,
  importe REAL DEFAULT 0,
  responsable TEXT,
  presupuestoId TEXT,
  notas TEXT,
  tareas_json TEXT,
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (clienteId) REFERENCES clients(id) ON DELETE RESTRICT
);

CREATE INDEX IF NOT EXISTS idx_projects_cliente ON projects(clienteId);
CREATE INDEX IF NOT EXISTS idx_projects_estado ON projects(estado);

-- 5. PRESUPUESTOS
CREATE TABLE IF NOT EXISTS quotes (
  id TEXT PRIMARY KEY,
  clienteId TEXT NOT NULL,
  fecha TEXT NOT NULL,
  validez TEXT,
  estado TEXT DEFAULT 'Borrador',
  subtotal REAL DEFAULT 0,
  descuentoTotal REAL DEFAULT 0,
  ivaTotal REAL DEFAULT 0,
  irpfTotal REAL DEFAULT 0,
  total REAL DEFAULT 0,
  condicionesPago TEXT,
  formaPago TEXT,
  plazoEntrega TEXT,
  revisiones TEXT,
  cancelacion TEXT,
  notas TEXT,
  observaciones TEXT,
  plantillaConfig_json TEXT,
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (clienteId) REFERENCES clients(id) ON DELETE RESTRICT
);

-- LÍNEAS DE PRESUPUESTO
CREATE TABLE IF NOT EXISTS quote_lines (
  id TEXT PRIMARY KEY,
  quoteId TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  cantidad REAL NOT NULL DEFAULT 1,
  precioUnitario REAL NOT NULL DEFAULT 0,
  iva REAL DEFAULT 21,
  descuento REAL DEFAULT 0,
  totalLinea REAL DEFAULT 0,
  orden INTEGER DEFAULT 0,
  FOREIGN KEY (quoteId) REFERENCES quotes(id) ON DELETE CASCADE
);

-- 6. FACTURAS
CREATE TABLE IF NOT EXISTS invoices (
  id TEXT PRIMARY KEY,
  clienteId TEXT NOT NULL,
  presupuestoId TEXT,
  proyectoId TEXT,
  fechaEmision TEXT NOT NULL,
  fechaVencimiento TEXT NOT NULL,
  formaPago TEXT,
  metodoPago TEXT,
  cuentaBancaria TEXT,
  baseImponible REAL DEFAULT 0,
  ivaTotal REAL DEFAULT 0,
  irpfTotal REAL DEFAULT 0,
  total REAL DEFAULT 0,
  importePagado REAL DEFAULT 0,
  importePendiente REAL DEFAULT 0,
  estado TEXT DEFAULT 'Borrador',
  notas TEXT,
  pieFactura TEXT,
  plantillaConfig_json TEXT,
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (clienteId) REFERENCES clients(id) ON DELETE RESTRICT
);

-- LÍNEAS DE FACTURA
CREATE TABLE IF NOT EXISTS invoice_lines (
  id TEXT PRIMARY KEY,
  invoiceId TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  cantidad REAL NOT NULL DEFAULT 1,
  precioUnitario REAL NOT NULL DEFAULT 0,
  iva REAL DEFAULT 21,
  descuento REAL DEFAULT 0,
  totalLinea REAL DEFAULT 0,
  orden INTEGER DEFAULT 0,
  FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
);

-- PAGOS DE FACTURA
CREATE TABLE IF NOT EXISTS invoice_payments (
  id TEXT PRIMARY KEY,
  invoiceId TEXT NOT NULL,
  fecha TEXT NOT NULL,
  importe REAL NOT NULL,
  metodo TEXT,
  referencia TEXT,
  notas TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (invoiceId) REFERENCES invoices(id) ON DELETE CASCADE
);

-- 7. FINANZAS Y MOVIMIENTOS
CREATE TABLE IF NOT EXISTS finances (
  id TEXT PRIMARY KEY,
  fecha TEXT NOT NULL,
  tipo TEXT NOT NULL,
  categoria TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  importe REAL NOT NULL,
  metodo TEXT,
  estado TEXT DEFAULT 'Completado',
  clienteId TEXT,
  proyectoId TEXT,
  facturaId TEXT,
  fechaCreacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 8. DOCUMENTOS
CREATE TABLE IF NOT EXISTS documents (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  categoria TEXT,
  tamano TEXT,
  tipo TEXT,
  fechaSubida TEXT,
  clienteId TEXT,
  proyectoId TEXT,
  rutaLocal TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 9. COMERCIAL
CREATE TABLE IF NOT EXISTS commercial_leads (
  id TEXT PRIMARY KEY,
  empresa TEXT NOT NULL,
  contacto TEXT,
  email TEXT,
  telefono TEXT,
  origen TEXT,
  servicioInteres TEXT,
  estado TEXT DEFAULT 'Contacto Inicial',
  valorEstimado REAL DEFAULT 0,
  fechaContacto TEXT,
  proximoSeguimiento TEXT,
  notas TEXT,
  fechaCreacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 10. PROVEEDORES
CREATE TABLE IF NOT EXISTS suppliers (
  id TEXT PRIMARY KEY,
  proveedor TEXT NOT NULL,
  cif TEXT,
  contacto TEXT,
  email TEXT,
  telefono TEXT,
  web TEXT,
  servicio TEXT,
  condiciones TEXT,
  estado TEXT DEFAULT 'Activo',
  notas TEXT,
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 11. PRODUCTOS
CREATE TABLE IF NOT EXISTS products (
  id TEXT PRIMARY KEY,
  nombre TEXT NOT NULL,
  referencia TEXT,
  categoria TEXT,
  descripcion TEXT,
  precio REAL DEFAULT 0,
  iva REAL DEFAULT 21,
  stock INTEGER DEFAULT 0,
  stockMinimo INTEGER DEFAULT 0,
  proveedorId TEXT,
  estado TEXT DEFAULT 'Disponible',
  fechaCreacion TEXT,
  fechaModificacion TEXT,
  isDemo INTEGER DEFAULT 0,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);

-- 12. ACTIVIDADES
CREATE TABLE IF NOT EXISTS activities (
  id TEXT PRIMARY KEY,
  fecha TEXT NOT NULL,
  descripcion TEXT NOT NULL,
  tipo TEXT NOT NULL,
  entidadId TEXT,
  targetView TEXT,
  targetId TEXT,
  created_at TEXT DEFAULT CURRENT_TIMESTAMP
);
